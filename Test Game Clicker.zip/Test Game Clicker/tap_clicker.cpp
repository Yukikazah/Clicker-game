
#include <iostream>
#include <vector>
#include <memory>

using namespace std;

// --- Observer Pattern for Quest System ---
class QuestObserver {
public:
    virtual void onMonsterDefeated() = 0;
    virtual void onGoldEarned(int amount) = 0;
    virtual ~QuestObserver() = default;
};

// --- Quest Base Class ---
class Quest : public QuestObserver {
protected:
    bool completed = false;
public:
    virtual void checkProgress() = 0;
    virtual bool isCompleted() const { return completed; }
    virtual void showStatus() const = 0;
};

// --- Defeat Monster Quest ---
class DefeatMonsterQuest : public Quest {
    int goal;
    int progress;
public:
    DefeatMonsterQuest(int g) : goal(g), progress(0) {}

    void onMonsterDefeated() override {
        if (completed) return;
        progress++;
        checkProgress();
    }

    void onGoldEarned(int) override {}

    void checkProgress() override {
        if (progress >= goal) {
            completed = true;
            cout << "Quest Completed: Defeated " << goal << " monsters!\n";
        }
    }

    void showStatus() const override {
        cout << "[Quest] Defeat Monsters: " << progress << "/" << goal << (completed ? " (Done)" : "") << "\n";
    }
};

// --- Earn Gold Quest ---
class EarnGoldQuest : public Quest {
    int goal;
    int progress;
public:
    EarnGoldQuest(int g) : goal(g), progress(0) {}

    void onMonsterDefeated() override {}

    void onGoldEarned(int amount) override {
        if (completed) return;
        progress += amount;
        checkProgress();
    }

    void checkProgress() override {
        if (progress >= goal) {
            completed = true;
            cout << "Quest Completed: Earned " << goal << " gold!\n";
        }
    }

    void showStatus() const override {
        cout << "[Quest] Earn Gold: " << progress << "/" << goal << (completed ? " (Done)" : "") << "\n";
    }
};

// --- Quest Manager ---
class QuestManager {
    vector<shared_ptr<Quest>> quests;
public:
    void addQuest(shared_ptr<Quest> quest) {
        quests.push_back(quest);
    }

    void notifyMonsterDefeated() {
        for (auto& q : quests)
            q->onMonsterDefeated();
    }

    void notifyGoldEarned(int gold) {
        for (auto& q : quests)
            q->onGoldEarned(gold);
    }

    void showQuests() const {
        for (auto& q : quests)
            q->showStatus();
    }
};

// --- Monster ---
class Monster {
    int hp;
public:
    Monster(int h) : hp(h) {}

    bool takeDamage(int dmg) {
        hp -= dmg;
        return hp <= 0;
    }

    void showHP() const {
        cout << "Monster HP: " << max(0, hp) << endl;
    }
};

// --- Player ---
class Player {
    int gold = 0;
public:
    int attackDamage = 1;

    void earnGold(int g) {
        gold += g;
        cout << "Earned " << g << " gold! Total Gold: " << gold << "\n";
    }

    int getGold() const { return gold; }
};

// --- Game Loop ---
int main() {
    Player player;
    QuestManager questManager;

    // Tambahkan quest
    questManager.addQuest(make_shared<DefeatMonsterQuest>(5));
    questManager.addQuest(make_shared<EarnGoldQuest>(20));

    Monster monster(5);

    cout << "=== Tap Titans (Console Version) ===\n";
    cout << "Tekan 't' untuk menyerang, 'q' untuk keluar.\n";

    char input;
    while (true) {
        monster.showHP();
        questManager.showQuests();

        cout << "\nAksi (t = tap/serang, q = quit): ";
        cin >> input;

        if (input == 'q') break;

        if (input == 't') {
            bool defeated = monster.takeDamage(player.attackDamage);
            cout << "Menyerang!\n";

            if (defeated) {
                cout << "Monster dikalahkan!\n";
                int reward = 5;
                player.earnGold(reward);
                questManager.notifyMonsterDefeated();
                questManager.notifyGoldEarned(reward);

                // Respawn monster
                monster = Monster(5);
            }
        }
    }

    cout << "\nGame selesai. Gold akhir: " << player.getGold() << "\n";
    return 0;
}
